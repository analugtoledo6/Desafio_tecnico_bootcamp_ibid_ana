﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace desafiobootcamp_ana
{
    internal class produto : conexao
    {

        private int idproduto;
        private int valor;
        private int quantidade;
        private string tipo;
        private string nome;
        private string datafab;

        public int _idproduto
        {
            get
            {
                return idproduto;
            }
            set
            {
                idproduto = value;
            }
        }

        public int _valor
        {
            get
            {
                return valor;
            }
            set
            {
                valor = value;
            }
        }

        public int _quantidade
        {
            get
            {
                return quantidade;
            }
            set
            {
                quantidade = value;
            }
        }

        public string _tipo
        {
            get
            {
                return tipo;
            }
            set
            {
                tipo = value;
            }
        }

        public string _nome
        {
            get
            {
                return nome;
            }
            set
            {
                nome = value;
            }
        }

        public string _datafab
        {
            get
            {
                return datafab;
            }
            set
            {
                datafab = value;
            }
        }

        public void inserir()
        {
            string query = "INSERT INTO produto (idproduto,valor,tipo,nome,datafab,quantidade) VALUES ('" + _idproduto + "','" + _valor + "','" + _tipo + "','" + _nome + "','" + _datafab + "','" + _quantidade + "' )";
            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                this.CloseConnection();
            }
        }


        public void apagar()
        {
            string query = "DELETE FROM produto WHERE idproduto = '" + _idproduto + "'";
            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                this.CloseConnection();
            }
        }

        public void alterar()
        {
            string query = "UPDATE produto SET idproduto ='" + _idproduto + "', valor = '" + _valor + "', tipo = '" + _tipo + "', nome ='" + _nome + "', datafab ='" + _datafab + "' , quantidade ='" + _quantidade + "' WHERE idproduto = '" + _idproduto + "'";
            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                this.CloseConnection();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Erro ao Atualizar");
            }
        }

       
    }

    
}
