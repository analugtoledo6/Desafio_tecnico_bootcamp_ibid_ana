namespace desafiobootcamp_ana
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 200)
            {
                progressBar1.Value += progressBar1.Step;
            }

            if (progressBar1.Value == 200)
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Hide();
                timer1.Stop();
            }

        }
    }
}