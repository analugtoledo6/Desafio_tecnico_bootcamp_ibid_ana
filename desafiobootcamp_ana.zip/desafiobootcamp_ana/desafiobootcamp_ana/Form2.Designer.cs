﻿namespace desafiobootcamp_ana
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            panel1 = new Panel();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txt_id = new TextBox();
            txt_datafab = new TextBox();
            txt_tipo = new TextBox();
            txt_nome = new TextBox();
            txt_valor = new TextBox();
            label8 = new Label();
            txt_quantidade = new TextBox();
            dataGridView1 = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sylfaen", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(280, 9);
            label1.Name = "label1";
            label1.Size = new Size(219, 36);
            label1.TabIndex = 0;
            label1.Text = "Cadastro Produto";
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(1, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 61);
            panel1.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(654, 101);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "Salvar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(654, 154);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 3;
            button2.Text = "Excluir";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(654, 209);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 4;
            button3.Text = "Alterar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 101);
            label2.Name = "label2";
            label2.Size = new Size(105, 20);
            label2.TabIndex = 5;
            label2.Text = "Id do produto:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 174);
            label3.Name = "label3";
            label3.Size = new Size(53, 20);
            label3.TabIndex = 6;
            label3.Text = "Nome:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(355, 174);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 7;
            label4.Text = "Valor:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(164, 292);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(355, 101);
            label6.Name = "label6";
            label6.Size = new Size(139, 20);
            label6.TabIndex = 9;
            label6.Text = "Data de fabricação:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(203, 101);
            label7.Name = "label7";
            label7.Size = new Size(42, 20);
            label7.TabIndex = 10;
            label7.Text = "Tipo:";
            // 
            // txt_id
            // 
            txt_id.Location = new Point(47, 124);
            txt_id.Name = "txt_id";
            txt_id.Size = new Size(125, 27);
            txt_id.TabIndex = 11;
            // 
            // txt_datafab
            // 
            txt_datafab.Location = new Point(355, 124);
            txt_datafab.Name = "txt_datafab";
            txt_datafab.Size = new Size(139, 27);
            txt_datafab.TabIndex = 12;
            // 
            // txt_tipo
            // 
            txt_tipo.Location = new Point(203, 124);
            txt_tipo.Name = "txt_tipo";
            txt_tipo.Size = new Size(125, 27);
            txt_tipo.TabIndex = 13;
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(47, 200);
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(281, 27);
            txt_nome.TabIndex = 14;
            // 
            // txt_valor
            // 
            txt_valor.Location = new Point(355, 200);
            txt_valor.Name = "txt_valor";
            txt_valor.Size = new Size(139, 27);
            txt_valor.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(47, 253);
            label8.Name = "label8";
            label8.Size = new Size(90, 20);
            label8.TabIndex = 16;
            label8.Text = "Quantidade:";
            // 
            // txt_quantidade
            // 
            txt_quantidade.Location = new Point(47, 276);
            txt_quantidade.Name = "txt_quantidade";
            txt_quantidade.Size = new Size(125, 27);
            txt_quantidade.TabIndex = 17;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(47, 339);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(701, 188);
            dataGridView1.TabIndex = 18;
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(800, 550);
            Controls.Add(dataGridView1);
            Controls.Add(txt_quantidade);
            Controls.Add(label8);
            Controls.Add(txt_valor);
            Controls.Add(txt_nome);
            Controls.Add(txt_tipo);
            Controls.Add(txt_datafab);
            Controls.Add(txt_id);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txt_id;
        private TextBox txt_datafab;
        private TextBox txt_tipo;
        private TextBox txt_nome;
        private TextBox txt_valor;
        private Label label8;
        private TextBox txt_quantidade;
        private DataGridView dataGridView1;
    }
}