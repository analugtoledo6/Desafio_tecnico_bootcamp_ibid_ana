﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace desafiobootcamp_ana
{
    public partial class Form2 : Form
    {
        conexao con = new conexao();
        string sql;
        MySqlCommand cmd;
        public Form2()
        {
            InitializeComponent();
        }

        private produto produto;
        produto pr = new produto();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                pr._idproduto = int.Parse(txt_id.Text);
                pr._valor = int.Parse(txt_valor.Text);
                pr._quantidade = int.Parse(txt_quantidade.Text);
                pr._tipo = (txt_tipo.Text);
                pr._nome = (txt_nome.Text);
                pr._datafab = (txt_datafab.Text);
                pr.inserir();
                limparcampos();
                listar();

            }

            finally
            {
                MessageBox.Show("Informações inseridas com sucesso");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                pr._idproduto = int.Parse(txt_id.Text);
                pr.apagar();
                limparcampos();
                listar();
            }

            finally
            {
                MessageBox.Show("Informações apagadas com sucesso");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                pr._idproduto = int.Parse(txt_id.Text);
                pr._valor = int.Parse(txt_valor.Text);
                pr._quantidade = int.Parse(txt_quantidade.Text);
                pr._tipo = (txt_tipo.Text);
                pr._nome = (txt_nome.Text);
                pr._datafab = (txt_datafab.Text);
                pr.alterar();
                limparcampos();
                listar();

            }

            finally
            {
                MessageBox.Show("Informações alteradas com sucesso");
            }
        }

        private void listar()
        {
            con.Initialize();
            sql = "Select * from produto order by idproduto asc";
            cmd = new MySqlCommand(sql, con.connection);
            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.CloseConnection();
        }

        private void limparcampos()
        {
            txt_nome.Text = "";
            txt_id.Text = "";
            txt_quantidade.Text = "";
            txt_valor.Text = "";
            txt_tipo.Text = "";
            txt_datafab.Text = "";
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_nome.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txt_id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txt_valor.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_tipo.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txt_datafab.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txt_quantidade.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
