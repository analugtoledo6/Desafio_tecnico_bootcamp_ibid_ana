﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace desafiobootcamp_ana
{
    internal class conexao
    {

        public MySqlConnection connection;
        public string server;
        public string database;
        public string uid;
        public string password;


        public conexao()
        {
            Initialize();
        }

        public void Initialize()
        {
            server = "localhost";
            database = "desafio_bootcamp";
            uid = "root";
            password = "1234";
            string conectionString;
            conectionString = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

            connection = new MySqlConnection(conectionString);
            
        }

        public bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }

            catch (MySqlException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        System.Windows.Forms.MessageBox.Show("Não foi possível conectar");
                        break;
                    case 1045:
                        System.Windows.Forms.MessageBox.Show("Inválido usuário e senha, verifique");
                        break;
                }
                return false;
            }

        }

        public bool CloseConnection()
        {

            try
            {
                connection.Close();
                return true;
            }

            catch (MySqlException ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
                return false;
            }

        }

        

    }
}
